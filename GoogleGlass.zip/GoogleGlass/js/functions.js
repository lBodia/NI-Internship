function showPreview()
{
	this.getElementsByClassName("image")[0].style.opacity = 0;
	this.getElementsByClassName("additionalImage")[0].style.opacity = 1;
}

function hidePreview()
{
	this.getElementsByClassName("image")[0].style.opacity = 1;
	this.getElementsByClassName("additionalImage")[0].style.opacity = 0;
}

$(document).ready(function() {
    

	var items = document.getElementsByClassName("item-m-p");
	var smallitems = document.getElementsByClassName("alsoList");
	if(smallitems.length)
	{
		smallitems = smallitems[0].getElementsByTagName("li");

		for(var i = 0; i < smallitems.length; i++ )
		{
			smallitems[i].onmouseover = showPreview;
			smallitems[i].onmouseout = hidePreview;
		}
	}

	for(var i = 0; i < items.length; i++ )
	{
		items[i].onmouseover = showPreview;
		items[i].onmouseout = hidePreview;
	}

	// Add shipping
	document.getElementById("shipping").onchange = function()
	{
		var country = this.options[this.selectedIndex].value;
		var countryItems = null;
		var countryName = this.options[this.selectedIndex].text;

		var shippings = document.getElementsByClassName("shipping");

		for(var i = 0; i < shippings.length; i++)
		{
			//shippings[i].parentNode.removeChild(shippings[i]);   // ???????????????? Why doesn't it work?????
		}

		$(".shipping").remove(); 


		switch(country) {
		  case '1':  
		  	break;

		  case '2': 
			countryItems = document.getElementsByClassName("item-m-p");
			
			for(var i = 0; i < countryItems.length; i+=2)
			{
				countryItems[i].innerHTML += '<div class="shipping">Shipping to ' + countryName + '</div>';
			}

		  	break;

		  default:
		    break;
		}

	}



});