


$(document).ready(function() {
    

    // Adding item to cart
	document.getElementById("addToCart").onclick = function()
	{
		this.innerHTML = "Товар доданий в корзину";
		this.style.backgroundColor = "#27ae60";
		this.style.borderColor = "#27ae60";

		var amount = parseInt(document.getElementById("itemAmount").value);
		var cartAmount = document.getElementById("cartCount").getElementsByTagName("b")[0];

		cartAmount.innerHTML = parseInt(cartAmount.innerHTML) + parseInt(amount);
	}

	// Change Img.Src Function
	function changePreview()
	{
		var src = this.getElementsByTagName("img")[0].getAttribute("data-big");
		document.getElementById("mainPhoto").setAttribute("src", src);
	}
	// Change Main Photo
	var previews = document.getElementById("itemPreviews").getElementsByTagName("li");
	for(var i = 0; i < previews.length; i++ )
	{
		previews[i].onclick = changePreview;
	}


	// $(".itemPage .previews li").click(function(){
	// 	$src = $(this).find("img").data("big");

	// 	$(".itemPage .mainPhoto").find("img").attr("src", $src);
	// });

	
	$(".bfh-number").each(function(){

		$prev = '<span class="input-group-addon bfh-number-btn inc"><span class="glyphicon glyphicon-chevron-up"></span></span>';
        $next = '<span class="input-group-addon bfh-number-btn dec"><span class="glyphicon glyphicon-chevron-down"></span>';

		$(this).after($prev,$next);
	});

	$(".bfh-number-btn.inc").click(function(){
		$field = $(this).parent().find(".bfh-number");

		if($field.val() >= $field.data("max"))
		{
			return false;
		}

		$field.get(0).value++;
		priceCount();
	});

	$(".bfh-number-btn.dec").click(function(){
		$field = $(this).parent().find(".bfh-number");

		if($field.val()-1 < $field.data("min"))
		{
			return false;
		}

		$field.get(0).value--;
		priceCount();
	});


	$('.bfh-number').keyup(function () { 
	    this.value = this.value.replace(/[^0-9\.]/g,'');
	});

	$(document).on('input', '.priceinput', priceCount);

	$price = parseInt($(".priceValue .number").html());
	function priceCount()
	{
		$(".priceValue .number").html($price * $(".priceinput").val());
	}
	
});