export class Item{
  name: string;
  itemPrice: number;
  quantity: number;
  url: string;
  discount: number = 0; 
}