"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var item_service_1 = require('./item.service');
var cart_component_1 = require('./cart.component');
var promo_code_component_1 = require('./promo-code.component');
var AppComponent = (function () {
    function AppComponent(itemService) {
        this.itemService = itemService;
    }
    AppComponent.prototype.getItems = function () {
        this.items = this.itemService.getItems();
    };
    AppComponent.prototype.ngOnInit = function () {
        this.getItems();
    };
    AppComponent.prototype.totalPrice = function () {
        var price = 0;
        for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
            var item = _a[_i];
            price += (item.itemPrice - item.discount) * item.quantity;
        }
        return price;
    };
    AppComponent.prototype.totalDiscount = function () {
        var discount = 0;
        for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
            var item = _a[_i];
            discount += item.discount;
        }
        return discount;
    };
    AppComponent.prototype.totalCount = function () {
        var count = 0;
        for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
            var item = _a[_i];
            count += item.quantity;
        }
        return count;
    };
    AppComponent.prototype.increment = function (item) {
        item.quantity++;
    };
    AppComponent.prototype.decrement = function (item) {
        if (item.quantity > 1) {
            item.quantity--;
        }
    };
    AppComponent.prototype.remove = function (item) {
        var i = this.items.indexOf(item);
        this.items.splice(i, 1);
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'check-out',
            template: "<div class=\"minicartab\"><mini-cart [count]=\"totalCount()\"></mini-cart></div>\n                <table class=\"table itemList\"><thead>\n              <tr>\n                  <th>\u0422\u043E\u0432\u0430\u0440</th>\n                  <th>\u041A\u0456\u043B\u044C\u043A\u0456\u0441\u0442\u044C</th>\n                  <th>\u0421\u0443\u043C\u0430</th>\n              </tr>\n              </thead>\n              <tbody>\n              <tr *ngFor=\"let item of items\" class=\"item\">\n                  <td><a href=\"{{item.url}}\">{{item.name}}</a></td>\n                  <td class=\"quantity\"><div class=\"input-group\"><input type=\"text\" id=\"itemAmount\" class=\"form-control priceinput bfh-number\" value=\"{{item.quantity}}\" data-min=\"1\" data-max=\"45\"> \n                  \n                  <span (click)=increment(item) class=\"input-group-addon bfh-number-btn inc\"><span class=\"glyphicon glyphicon-chevron-up\"></span></span>\n                  \n                  <span (click)=decrement(item) class=\"input-group-addon bfh-number-btn dec\"><span class=\"glyphicon glyphicon-chevron-down\"></span></span>\n                  \n                  </div></td>\n                  <td><span class=\"itemPrice\">{{(item.itemPrice - item.discount) * item.quantity}}</span> \u0433\u0440\u043D.</td>\n                  <td><span (click)=remove(item) class=\"glyphicon glyphicon-remove removeItem\" aria-hidden=\"true\"></span></td>\n              </tr>\n              <tr>\n                <td colspan=\"4\" class=\"row\"><promo-code [items]=\"items\"></promo-code></td>\n              </tr>\n              <tr>\n                  <td colspan=\"2\"><b>\u0417\u043D\u0438\u0436\u043A\u0430</b></td>\n                  <td colspan=\"2\" class=\"text-right\"><b><span class=\"total\">{{totalDiscount()}}</span> \u0433\u0440\u043D.</b></td>\n              </tr>\n              <tr>\n                  <td colspan=\"2\"><b>\u0414\u043E \u0441\u043F\u043B\u0430\u0442\u0438</b></td>\n                  <td colspan=\"2\" class=\"text-right\"><b><span class=\"total\">{{totalPrice()}}</span> \u0433\u0440\u043D.</b></td>\n              </tr>\n              </tbody>\n         </table>",
            providers: [item_service_1.ItemService],
            directives: [promo_code_component_1.PromoCodeComponent, cart_component_1.CartComponent],
        }), 
        __metadata('design:paramtypes', [item_service_1.ItemService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map