import {Injectable} from '@angular/core';

import { Item } from './item';
import { ITEMS } from './mock-item';

@Injectable()
export class ItemService {
  getItems() {
    return ITEMS;
  }
}