"use strict";
exports.ITEMS = [
    { name: "Google Glass 3.0 Shale", itemPrice: 22000, quantity: 2, url: "item.html", discount: 0 },
    { name: "Google Glass 3.0 Black", itemPrice: 25000, quantity: 1, url: "item.html", discount: 0 },
    { name: "Google Glass 3.0 White", itemPrice: 27000, quantity: 1, url: "item.html", discount: 0 }
];
//# sourceMappingURL=mock-item.js.map