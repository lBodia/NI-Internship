import { Component, Output } from '@angular/core';
import { Item } from './item';
import { ItemService } from './item.service';
import { OnInit } from '@angular/core';
import { CartComponent } from './cart.component';
import { PromoCodeComponent } from './promo-code.component';

@Component({
    selector: 'check-out',
    template: `<div class="minicartab"><mini-cart [count]="totalCount()"></mini-cart></div>
                <table class="table itemList"><thead>
              <tr>
                  <th>Товар</th>
                  <th>Кількість</th>
                  <th>Сума</th>
              </tr>
              </thead>
              <tbody>
              <tr *ngFor="let item of items" class="item">
                  <td><a href="{{item.url}}">{{item.name}}</a></td>
                  <td class="quantity"><div class="input-group"><input type="text" id="itemAmount" class="form-control priceinput bfh-number" value="{{item.quantity}}" data-min="1" data-max="45"> 
                  
                  <span (click)=increment(item) class="input-group-addon bfh-number-btn inc"><span class="glyphicon glyphicon-chevron-up"></span></span>
                  
                  <span (click)=decrement(item) class="input-group-addon bfh-number-btn dec"><span class="glyphicon glyphicon-chevron-down"></span></span>
                  
                  </div></td>
                  <td><span class="itemPrice">{{(item.itemPrice - item.discount) * item.quantity}}</span> грн.</td>
                  <td><span (click)=remove(item) class="glyphicon glyphicon-remove removeItem" aria-hidden="true"></span></td>
              </tr>
              <tr>
                <td colspan="4" class="row"><promo-code [items]="items"></promo-code></td>
              </tr>
              <tr>
                  <td colspan="2"><b>Знижка</b></td>
                  <td colspan="2" class="text-right"><b><span class="total">{{totalDiscount()}}</span> грн.</b></td>
              </tr>
              <tr>
                  <td colspan="2"><b>До сплати</b></td>
                  <td colspan="2" class="text-right"><b><span class="total">{{totalPrice()}}</span> грн.</b></td>
              </tr>
              </tbody>
         </table>`,
    providers: [ItemService],
	directives: [PromoCodeComponent, CartComponent],
})

export class AppComponent implements OnInit{

    items: Item[];
    constructor(private itemService: ItemService) { }

    getItems() {
        this.items = this.itemService.getItems();
    }

    ngOnInit() {
        this.getItems();
    }

    totalPrice(){
	    var price: number = 0;
        for (var item of this.items)
        { 
            price += (item.itemPrice - item.discount) * item.quantity;
        }
        return price;
    }

    totalDiscount(){
	    var discount: number = 0;
        for (var item of this.items)
        { 
            discount += item.discount;
        }
        return discount;
    }

    totalCount(){
	    var count: number = 0;
        for (var item of this.items)
        { 
            count += item.quantity;
        }
        return count;
    }

	increment(item:Item){
	    item.quantity++;
	}

	decrement(item:Item){
        if(item.quantity > 1)
        {
            item.quantity--;
        }
	}

	remove(item:Item){
        let i = this.items.indexOf(item);
        this.items.splice(i, 1);
	}
}
