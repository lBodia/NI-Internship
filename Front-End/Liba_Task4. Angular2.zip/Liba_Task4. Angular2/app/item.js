"use strict";
var Item = (function () {
    function Item() {
        this.discount = 0;
    }
    return Item;
}());
exports.Item = Item;
//# sourceMappingURL=item.js.map