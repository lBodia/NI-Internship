"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var PromoCode = (function () {
    function PromoCode() {
    }
    PromoCode.promos = ["ni16%", "ni33%", "ni10$"];
    return PromoCode;
}());
var PromoCodeComponent = (function () {
    function PromoCodeComponent() {
        this.newItems = this.items;
        this.promovalue = PromoCode.inputValue;
    }
    PromoCodeComponent.prototype.promo = function () {
        if (this.promovalue == PromoCode.promos[0])
            for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
                var item = _a[_i];
                item.discount = item.itemPrice * 0.16;
            }
        if (this.promovalue == PromoCode.promos[1])
            for (var _b = 0, _c = this.items; _b < _c.length; _b++) {
                var item = _c[_b];
                item.discount = item.itemPrice * 0.33;
            }
        if (this.promovalue == PromoCode.promos[2])
            for (var _d = 0, _e = this.items; _d < _e.length; _d++) {
                var item = _e[_d];
                item.discount = 10;
            }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], PromoCodeComponent.prototype, "items", void 0);
    PromoCodeComponent = __decorate([
        core_1.Component({
            selector: 'promo-code',
            template: "\n            <div class=\"row\">\n                <div class=\"col-md-7\">    \n                    <input type=\"text\" [(ngModel)]=\"promovalue\" class=\"form-control\" placeholder=\"\u041F\u0440\u043E\u043C\u043E\u043A\u043E\u0434\"> \n                </div>\n                <div class=\"col-md-5\">    \n                    <input type=\"submit\" (click)=promo() class=\"btn btn-warning btn-block\" value=\"OK\">\n                </div>\n            </div>"
        }), 
        __metadata('design:paramtypes', [])
    ], PromoCodeComponent);
    return PromoCodeComponent;
}());
exports.PromoCodeComponent = PromoCodeComponent;
//# sourceMappingURL=promo-code.component.js.map