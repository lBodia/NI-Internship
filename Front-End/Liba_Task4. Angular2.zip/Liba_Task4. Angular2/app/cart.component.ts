import { Component, Input } from '@angular/core';
import { AppComponent } from './app.component';


@Component({
    selector: 'mini-cart',
    template: `<a id="smallCart" href="checkout.html">
                    <i class="glyphicon glyphicon-shopping-cart"></i>
                   <span class="smallCartCount badge">{{count}}</span> 
                </a>`,    
})


export class CartComponent{
  @Input() 
  count: number;
}