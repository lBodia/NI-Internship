import { Component, Input } from '@angular/core';
import { AppComponent } from './app.component';

import { Item } from './item';

class PromoCode
{
    static inputValue: string;
	static promos = ["ni16%", "ni33%", "ni10$"];
    static originItems: Item[];
}

@Component({
    selector: 'promo-code',
    template: `
            <div class="row">
                <div class="col-md-7">    
                    <input type="text" [(ngModel)]="promovalue" class="form-control" placeholder="Промокод"> 
                </div>
                <div class="col-md-5">    
                    <input type="submit" (click)=promo() class="btn btn-warning btn-block" value="OK">
                </div>
            </div>`
})


export class PromoCodeComponent{

	@Input() items: Item[];

	newItems: Item[] = this.items;

	promovalue = PromoCode.inputValue;
   
    promo()
    {
        if(this.promovalue == PromoCode.promos[0])
            for (var item of this.items)
                item.discount = item.itemPrice * 0.16;

        if(this.promovalue == PromoCode.promos[1])
            for (var item of this.items)
                item.discount = item.itemPrice * 0.33;

        if(this.promovalue == PromoCode.promos[2])
            for (var item of this.items)
                item.discount = 10;
    }
}

